tar -cvf handin.tar -X exclude.txt models MCQ mytorch 

